References:
* L-TAGE Branch Predictor https://www.jilp.org/vol9/v9paper6.pdf
* PPM like tag-based predictor https://www.jilp.org/vol7/v7paper10.pdf
* https://manikantareddyd.github.io/blog/dynamic-branch-predictors/